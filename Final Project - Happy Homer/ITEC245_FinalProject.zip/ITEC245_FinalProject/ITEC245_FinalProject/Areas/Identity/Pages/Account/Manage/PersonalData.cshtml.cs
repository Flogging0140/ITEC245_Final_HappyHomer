﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using TheHappyHomer.Models;

namespace TheHappyHomer.Areas.Identity.Pages.Account.Manage
{
    [Authorize(Roles = "User,Manager")]
    public class PersonalDataModel : PageModel
    {
        private readonly UserManager<UserExtended> _userManager;
        private readonly SignInManager<UserExtended> _signInManager;
        private readonly ILogger<PersonalDataModel> _logger;

        public PersonalDataModel(
            UserManager<UserExtended> userManager,
            ILogger<PersonalDataModel> logger,
            SignInManager<UserExtended> signInManager)
        {
            _userManager = userManager;
            _logger = logger;
            _signInManager = signInManager;
        }

        [BindProperty]
        public InputModel Input { get; set; }

        public string StatusMessage { get; set; }


        //public async Task<IActionResult> OnGet()
        //{
        //    var user = await _userManager.GetUserAsync(User);
        //    if (user == null)
        //    {
        //        return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
        //    }

        //    return Page();
        //}

        public async Task<IActionResult> OnGetAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            Input = new InputModel
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                PhoneNumber = user.PhoneNumber,
                Address = user.Address,
                City = user.City,
                Province = user.Province,
                PostalCode = user.PostalCode,
                CreditCardNumber = user.CreditCardNumber,
                CreditCardExpiry = user.CreditCardExpiry,
                CreditCardCVV = user.CreditCardCVV
            };

            return Page();
        }


        public async Task<IActionResult> OnPostAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            if (!ModelState.IsValid)
            {
                return Page();
            }

            user.FirstName = Input.FirstName;
            user.LastName = Input.LastName;
            user.PhoneNumber = Input.PhoneNumber;
            user.Address = Input.Address;
            user.City = Input.City;
            user.Province = Input.Province;
            user.PostalCode = Input.PostalCode;
            user.CreditCardNumber = Input.CreditCardNumber;
            user.CreditCardExpiry = Input.CreditCardExpiry;
            user.CreditCardCVV = Input.CreditCardCVV;

            var result = await _userManager.UpdateAsync(user);
            if (!result.Succeeded)
            {
                throw new InvalidOperationException($"Unexpected error occurred updating the user's custom properties for user with ID '{user.Id}'.");
            }

            await _signInManager.RefreshSignInAsync(user);
            StatusMessage = "Your profile has been updated";
            return RedirectToPage();
        }

    }

    public class InputModel
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }

        [Phone(ErrorMessage = "Invalid phone number.")]
        public string? PhoneNumber { get; set; }

        [Required(ErrorMessage = "Address is required.")]
        public string? Address { get; set; }

        public string? City { get; set; }

        public string? Province { get; set; }
        [RegularExpression(@"^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$", ErrorMessage = "Invalid postal code.")]
        public string? PostalCode { get; set; }

        [Required(ErrorMessage = "Credit card number is required.")]
        [CreditCard(ErrorMessage = "Invalid credit card number.")]
        public string? CreditCardNumber { get; set; }

        [Required(ErrorMessage = "Credit card expiry is required.")]
        [RegularExpression(@"^(0[1-9]|1[0-2])\/?([0-9]{4}|[0-9]{2})$", ErrorMessage = "Invalid credit card expiry. Format: MM/YY or MM/YYYY.")]
        public string? CreditCardExpiry { get; set; }

        [Required(ErrorMessage = "Credit card CVV is required.")]
        [RegularExpression(@"^[0-9]{3,4}$", ErrorMessage = "Invalid credit card CVV.")]
        public string? CreditCardCVV { get; set; }
    }
}
