﻿using ITEC245_FinalProject.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using TheHappyHomer.Models;
using TheHappyHomer.ViewComponents;

namespace TheHappyHomer.ViewComponents
{
    public class CartCountComponent : ViewComponent
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<UserExtended> _userManager;
        private UserExtended _user;

        public CartCountComponent(ApplicationDbContext context, UserManager<UserExtended> userManager)
        {
            _userManager = userManager;
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            _user = await _userManager.GetUserAsync(HttpContext.User);

            Order? order = await _context.Orders
                    .Where(o => o.UserId == _user.Id && o.HasBeenOrdered == false)
                    .Include(o => o.OrderedProducts)
                    .FirstOrDefaultAsync();

            if (order != null)
            {
                int productCount = order.OrderedProducts.Sum(p => p.Quantity);

                return View(productCount);
            }
            else 
                return View(0);
        }
    }
}
