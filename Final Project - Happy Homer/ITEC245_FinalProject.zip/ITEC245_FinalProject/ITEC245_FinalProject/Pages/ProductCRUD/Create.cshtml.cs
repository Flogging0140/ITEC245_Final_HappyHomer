﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ITEC245_FinalProject.Data;
using TheHappyHomer.Models;
using Microsoft.AspNetCore.Authorization;

namespace TheHappyHomer.Pages.ProductCRUD
{
    // Pretty sure don't need to care about this because out of scope for assignment
    [Authorize]
    public class CreateModel : PageModel
    {
        private readonly ITEC245_FinalProject.Data.ApplicationDbContext _context;

        public CreateModel(ITEC245_FinalProject.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Product Product { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.Products == null || Product == null)
            {
                return Page();
            }

            _context.Products.Add(Product);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
