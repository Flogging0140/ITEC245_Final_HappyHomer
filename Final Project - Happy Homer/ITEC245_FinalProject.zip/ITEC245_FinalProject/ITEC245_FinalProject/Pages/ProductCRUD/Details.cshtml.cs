﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ITEC245_FinalProject.Data;
using TheHappyHomer.Models;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace TheHappyHomer.Pages.ProductCRUD
{
    [Authorize(Roles = "User,Manager")]
    public class DetailsModel : PageModel
    {
        private readonly ITEC245_FinalProject.Data.ApplicationDbContext _context;

        public DetailsModel(ITEC245_FinalProject.Data.ApplicationDbContext context)
        {
            _context = context;
        }

      public Product Product { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Products == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Where(o => o.Id == id)
                .FirstOrDefaultAsync();

            if (product == null)
            {
                return NotFound();
            }
            else 
            {
                Product = product;
            }
            return Page();
        }
    }
}
