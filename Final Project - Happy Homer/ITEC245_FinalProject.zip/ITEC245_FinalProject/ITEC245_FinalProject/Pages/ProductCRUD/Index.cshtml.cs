﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ITEC245_FinalProject.Data;
using TheHappyHomer.Models;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace TheHappyHomer.Pages.ProductCRUD
{
    [Authorize(Roles = "Manager")]
    public class IndexModel : PageModel
    {
        private readonly ITEC245_FinalProject.Data.ApplicationDbContext _context;

        public IndexModel(ITEC245_FinalProject.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Product> Product { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Products != null)
            {
                Product = await _context.Products.ToListAsync();
            }
        }

        public async Task<IActionResult> OnPostAsyncToggleVisibility(int ToggleVisibilityProductId)
        {
            var product = await _context.Products.FindAsync(ToggleVisibilityProductId);

            if (product != null)
            {
                product.VisibleToCustomer = !product.VisibleToCustomer;
                await _context.SaveChangesAsync();
            }

            return RedirectToPage();
        }

    }
}
