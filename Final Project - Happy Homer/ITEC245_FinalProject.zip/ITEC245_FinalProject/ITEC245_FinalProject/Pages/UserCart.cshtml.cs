﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ITEC245_FinalProject.Data;
using TheHappyHomer.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using System.Runtime.InteropServices;
using Microsoft.AspNetCore.Identity;

namespace TheHappyHomer.Pages
{
    [Authorize(Roles = "User")]
    public class UserCartModel : PageModel
    {
        // Doing some stuff like in the scaffolded stuff
        private readonly ApplicationDbContext _context;
        private readonly UserManager<UserExtended> _userManager;
        private UserExtended _user;

        // Some sort of >>black magic happens here<<, dependancy injection ig
        public UserCartModel(ApplicationDbContext context,
            UserManager<UserExtended> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IList<OrderedProduct?> CurrentCart { get; set; } = default!;

        public async Task OnGetAsync()
        {
            _user = await _userManager.GetUserAsync(User);

            if (_context.Products != null)
            {
                Order? tmpUserCart = await _context.Orders
                    .Where(o => o.UserId == _user.Id && o.HasBeenOrdered == false)
                    .Include(o => o.OrderedProducts)
                    .ThenInclude(o => o.myOrderedProduct)
                    .FirstOrDefaultAsync();

                // We have user cart?
                if (tmpUserCart != null)
                {
                    // Is there products in their cart?
                    if (tmpUserCart.OrderedProducts != null)
                    {
                        // Yes, lets display it
                        CurrentCart = tmpUserCart.OrderedProducts;
                    }
                    // No? Do nothing IG
                    // TODO: display something
                }
            }
        }

        /* TODO: Get the product passed as JSON, update the session of cart after adding product */

        public async Task<IActionResult> OnGetAsyncProductId(int productId)
        {
            _user = await _userManager.GetUserAsync(User);

            // Get product they chose, from products, to add to ordered
            Product? chosenProduct = await _context.Products.Where(p => p.Id == productId).FirstOrDefaultAsync();

            // Create new ordered product
            OrderedProduct productToOrder = new OrderedProduct()
            {
                myOrderedProduct = chosenProduct,
                Quantity = 1
            };

            // Get user ID
            string userId = (await _userManager.GetUserAsync(User)).Id;

            if (chosenProduct != null)
            {
                // Gets order that is current (has not been ordered yet)
                // If not ordered then is current cart
                Order? order = await _context.Orders
                    .Where(o => o.UserId == _user.Id && o.HasBeenOrdered == false)
                    .Include(o => o.OrderedProducts)
                    .ThenInclude(o => o.myOrderedProduct)
                    .FirstOrDefaultAsync();

                // We've got cart?
                if (order != null)
                {
                    // check if quantity > 1
                    int productCount = order.OrderedProducts
                        .Where(p => p.myOrderedProduct.Id == chosenProduct.Id)
                        .Count();
                    if (productCount > 0)
                    {
                        // Just add quantity, not new product
                        OrderedProduct orderedProduct = order.OrderedProducts.Where(p => p.myOrderedProduct.Id == chosenProduct.Id).FirstOrDefault();
                        orderedProduct.Quantity++;
                    }
                    else
                    {
                        // Add new product
                        order.OrderedProducts.Add(productToOrder);
                    }

                    // Display order
                    CurrentCart = order.OrderedProducts;

                    // DB stuff
                    _context.Update(order);
                    _context.SaveChanges();
                }
                else
                {
                    // Create order for this person
                    order = new Order
                    {
                        UserId = _user.Id,
                        HasBeenOrdered = false,
                        OrderedProducts = new List<OrderedProduct?> { productToOrder }
                    };

                    // Display
                    CurrentCart = order.OrderedProducts;

                    // Save back into db
                    _context.Add(order);
                    _context.SaveChanges();
                }
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostAsyncDeleteProduct(int productId)
        {
            _user = await _userManager.GetUserAsync(User);

            Product? product = await _context.Products.Where(p => p.Id == productId).FirstOrDefaultAsync();

            Order? order = await _context.Orders
                    .Where(o => o.UserId == _user.Id && o.HasBeenOrdered == false)
                    .Include(o => o.OrderedProducts)
                    .ThenInclude(o => o.myOrderedProduct)
                    .FirstOrDefaultAsync();

            if (order != null && product != null)
            {
                // Our ordered product, TO DELETE
                OrderedProduct orderedProduct = order.OrderedProducts.Where(p => p.myOrderedProduct.Id == product.Id).FirstOrDefault();

                if (orderedProduct != null)
                {
                    // Decriment count if greater than 1
                    if (orderedProduct.Quantity > 1)
                        orderedProduct.Quantity--;

                    // Otherwise remove it from ordered products
                    else
                        order.OrderedProducts.Remove(orderedProduct);

                    // DB stuff
                    _context.Update(order);
                    _context.SaveChanges();

                    // Display order
                    CurrentCart = order.OrderedProducts;
                }
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostAsyncDeleteOrder()
        {
            _user = await _userManager.GetUserAsync(User);
            Order? order = await _context.Orders
                    .Where(o => o.UserId == _user.Id)
                    .Include(o => o.OrderedProducts)
                    .ThenInclude(o => o.myOrderedProduct)
                    .FirstOrDefaultAsync();
            if (order != null)
            {
                // Remove order
                _context.Remove(order);
                _context.SaveChanges();
                // Display order
                CurrentCart = order.OrderedProducts;
            }
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostAsyncCheckout()
        {
            _user = await _userManager.GetUserAsync(User);
            Order? order = await _context.Orders
                    .Where(o => o.UserId == _user.Id && o.HasBeenOrdered == false)
                    .Include(o => o.OrderedProducts)
                    .ThenInclude(o => o.myOrderedProduct)
                    .FirstOrDefaultAsync();
            if (order != null)
            {
                // Set order to ordered
                order.HasBeenOrdered = true;
                // DB stuff
                _context.Update(order);
                _context.SaveChanges();
                // Display order
                CurrentCart = order.OrderedProducts;
            }
            return RedirectToPage("Checkout");
        }
    }
}
