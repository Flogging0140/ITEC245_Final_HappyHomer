﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ITEC245_FinalProject.Data;
using TheHappyHomer.Models;
using Microsoft.AspNetCore.Authorization;

namespace TheHappyHomer.Pages.OrderCRUD
{
    // Deny access to anyone, at least until I figure out how I want this to work
    [Authorize]
    public class CreateModel : PageModel
    {
        private readonly ITEC245_FinalProject.Data.ApplicationDbContext _context;

        public CreateModel(ITEC245_FinalProject.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Order Order { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.Orders == null || Order == null)
            {
                return Page();
            }

            _context.Orders.Add(Order);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
