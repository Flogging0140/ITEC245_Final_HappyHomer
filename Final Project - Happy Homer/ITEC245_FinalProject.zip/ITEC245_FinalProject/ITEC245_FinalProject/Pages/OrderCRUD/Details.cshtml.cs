﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ITEC245_FinalProject.Data;
using TheHappyHomer.Models;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace TheHappyHomer.Pages.OrderCRUD
{
    [Authorize(Roles = "User,Manager")]
    public class DetailsModel : PageModel
    {
        private readonly ITEC245_FinalProject.Data.ApplicationDbContext _context;

        public DetailsModel(ITEC245_FinalProject.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public Order Order { get; set; } = default!;

        [BindProperty]
        public string UserNameForOrder { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Orders == null)
            {
                return NotFound();
            }

            var order = await _context.Orders.FirstOrDefaultAsync(m => m.Id == id);

            if (order == null)
            {
                return NotFound();
            }
            else
            {

                // get user name for order
                var user = await _context.Users.FirstOrDefaultAsync(m => m.Id == order.UserId);

                // Set UserNameForOrder to user
                UserNameForOrder = user.UserName;

                Order = order;
            }
            return Page();
        }
    }
}
