using ITEC245_FinalProject.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Data;
using TheHappyHomer.Models;

namespace TheHappyHomer.Pages
{
    [Authorize(Roles = "User")]
    public class CheckoutModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<UserExtended> _userManager;
        private UserExtended _user;

        // Some sort of >>black magic happens here<<, dependancy injection ig
        public CheckoutModel(ApplicationDbContext context,
            UserManager<UserExtended> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // Orders that have been submited
        [BindProperty]
        public IList<Order> OrderedProducts { get; set; }

        // bind property for string UserNameForOrder
        [BindProperty]
        public string UserNameForOrder { get; set; }

        [BindProperty]
        public string UserEmailForOrder { get; set; }

        [BindProperty]
        public decimal? TotalPrice { get; set; } = 0;

        public async Task OnGetAsync()
        {
            _user = await _userManager.GetUserAsync(User);

            UserNameForOrder = $"{_user.FirstName}_{_user.LastName}";

            // kinda jank but I am handeling in front end
            if (UserNameForOrder=="_")
                UserNameForOrder = null;

            if (_user.Email != null)
                UserEmailForOrder = _user.Email;

            if (_context.Products != null)
            {
                List<Order>? UserOrderedOrderes = await _context.Orders
                    .Where(o => o.UserId == _user.Id 
                        && o.HasBeenOrdered == true 
                        && o.OrderedProducts.Count > 0)
                    .Include(o => o.OrderedProducts)
                    .ThenInclude(o => o.myOrderedProduct)
                    .ToListAsync();

                // We have submited orders?
                if (UserOrderedOrderes != null)
                {
                    // Display the total price of all ordered products in all submited orders
                    foreach (Order order in UserOrderedOrderes)
                    {
                        foreach (OrderedProduct orderedProduct in order.OrderedProducts)
                        {
                            if (orderedProduct != null)
                            {
                                if (orderedProduct.Quantity > 1)
                                {
                                    TotalPrice += orderedProduct.Quantity * orderedProduct.myOrderedProduct.ProductPrice;
                                }
                                else
                                    TotalPrice += orderedProduct.myOrderedProduct.ProductPrice;
                            }
                        }
                    }

                    // Yes, lets display it
                    OrderedProducts = UserOrderedOrderes;
                }
            }
        }
    }
}
