﻿using Microsoft.AspNetCore.Identity;

namespace TheHappyHomer.Models
{
    public class Order
    {
        public int Id { get; set; }
        public List<OrderedProduct?> OrderedProducts { get; set; }
        public DateTime DateOrdered { get; set; }
        public string UserId { get; set; } // Forein key for the user who placed the order
        public bool HasBeenOrdered { get; set; }
    }
}
