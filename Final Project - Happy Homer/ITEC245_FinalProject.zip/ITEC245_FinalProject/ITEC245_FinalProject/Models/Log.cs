﻿namespace TheHappyHomer.Models
{
    public class Log
    {
        public int Id { get; set; }
        public bool Worked { get; set; }
        public string? Message { get; set; }
    }
}
