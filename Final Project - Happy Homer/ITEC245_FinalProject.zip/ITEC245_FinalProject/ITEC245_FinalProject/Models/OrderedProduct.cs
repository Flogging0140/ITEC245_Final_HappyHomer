﻿using System.ComponentModel.DataAnnotations.Schema;

namespace TheHappyHomer.Models
{
    public class OrderedProduct
    {
        // Added forein key and prop prod id to setup cascade
        public int Id { get; set; }
        [ForeignKey("MyOrderedProductId")]
        public Product? myOrderedProduct { get; set; }
        public int MyOrderedProductId { get; set; }
        public int Quantity { get; set; }
    }
}
