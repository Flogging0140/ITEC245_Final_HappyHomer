﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace TheHappyHomer.Models
{
    public class UserExtended : IdentityUser
    {
        // string property firstname
        public string? FirstName { get; set; }
        // string property lastname
        public string? LastName { get; set; }
        // string property email
        public string? Email { get; set; }
        // string property phonenumber length 10
        [MaxLength(10)]
        public string? PhoneNumber { get; set; }

        // string credit cart number
        public string? CreditCardNumber { get; set; }
        // string credit cart expiry
        public string? CreditCardExpiry { get; set; }
        // string credit cart cvv
        public string? CreditCardCVV { get; set; }

        // string property address
        public string? Address { get; set; }
        // string property city
        public string? City { get; set; }
        // string property province
        public string? Province { get; set; }
        // string property postalcode
        public string? PostalCode { get; set; }
    }
}
