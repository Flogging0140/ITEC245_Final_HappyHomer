﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Xml;
using TheHappyHomer.Models;

namespace ITEC245_FinalProject.Data
{
    public class ApplicationDbContext : IdentityDbContext<UserExtended>
    {
        // Orders uses have
        public DbSet<Order> Orders { get; set; }

        // Products the site sells
        public DbSet<Product> Products { get; set; }

        // Track the products the user has in their order
        public DbSet<OrderedProduct> OrderedProducts { get; set; }

        // Logs for pushing errors too
        public DbSet<Log> Logs { get; set; }


        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Order>()
                .HasOne<UserExtended>()
                .WithMany()
                .HasForeignKey(o => o.UserId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Cascade);

            // confugure cascade delete for products
            modelBuilder.Entity<OrderedProduct>()
                .HasOne(op => op.myOrderedProduct)
                .WithMany()
                .HasForeignKey(op => op.MyOrderedProductId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}