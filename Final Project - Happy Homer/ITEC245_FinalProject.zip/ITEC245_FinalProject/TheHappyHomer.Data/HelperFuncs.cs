﻿namespace TheHappyHomer.Data
{
    public static class HelperFuncs
    {

    }
}